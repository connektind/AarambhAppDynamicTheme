package com.example.aarambhappdynamictheme.activity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.aarambhappdynamictheme.R;

import java.util.ArrayList;

public class SubscribeNowActivity extends AppCompatActivity {
    ImageView back_btn,tab_profile_icon;
    TextView tab_profile_name;
    ArrayList<String> you_Chapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscribe_now);
        checkOrientation();
        init();
        listner();
    }
    private void checkOrientation() {
        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }


    private void listner() {
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }
    @Override
    public void finish() {
        Intent in=new Intent(RedThemeSubscribeNowActivity.this, DashBoardSixthStandardActivity.class);
        in.putExtra("DataDashBoard6th", you_Chapter);
        //  in.putExtra("LandDetail", landDetailModel);
        in.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        setResult(RESULT_OK, in);
        super.finish();
    }


    private void init() {
        you_Chapter=new ArrayList<>();
        back_btn=(ImageView)findViewById(R.id.back_btn_subscribe);
        try {
            tab_profile_icon=(ImageView) findViewById(R.id.img_profile_tab);
            tab_profile_name=(TextView) findViewById(R.id.student_name_red);
            tab_profile_name.setText(AarambhSharedPreference.loadStudentNameFromPreference(this));
            Glide.with(this).load(urlProfileImg)
                    .crossFade()
                    .thumbnail(0.5f)
                    .bitmapTransform(new CircleTransform(this))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(tab_profile_icon);

        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
