package com.example.aarambhappdynamictheme.activity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.aarambhappdynamictheme.R;

import java.util.ArrayList;

public class SubjectActivity extends AppCompatActivity {
    TextView subj_name, practice, test;
    LinearLayout linearLayout_back_theme;
    ArrayList<SubjectChapterListModel> subjectChapterListModelArrayList;
    SubjectChapterListModel subjectChapterListModel;
    SubjectChapterListAdapter subjectChapterListAdapter;
    RecyclerView chapter_list_Recyclerview;
    String subject_name, course_id;
    CardView pratices_Chapter, test_subjcet;
    ProgressDialog progressdialog;
    TextView number_chapters;
    //    Button back_btn;
    ImageView profile_subject_tab,back_btn;
    TextView student_name;
    ArrayList<VideoDetails>videoDetailsArrayList;
    ArrayList<String> you_Chapter;
    ArrayList<VideoDetails> new_arrayListVideoDetails;
    ArrayList<YouTubePlayList> playListArrayList;
    YouTubeTitle sixth_Details;
    //Dynamic Theme
    LinearLayout background_theme;
    Bitmap myImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        checkOrientation();
        subject_name = AarambhSharedPreference.loadSubjectNameFromPreference(this);
        //course_id = AarambhSharedPreference.loadCourseIdFromPreference(this);
        //  class_id = AarambhSharedPreference.loadClassIdFromPreference(this);
        init();
        listner();
        // getChapterApiCalling();

        //  getTopicApiCalling(subjectChapterListModel.getTopicId());
        try {
            sixth_Details = (YouTubeTitle) getIntent().getSerializableExtra("6thDetails_chapter");
            //new_arrayListVideoDetails = (ArrayList<VideoDetails>) getIntent().getSerializableExtra("6thDetails_chapter_video");
            playListArrayList = (ArrayList<YouTubePlayList>) getIntent().getSerializableExtra("PlayList");
            you_Chapter = new ArrayList<>();
            ArrayList<String> videoName = new ArrayList<>();

            //you_Chapter = sixth_Details.getChapter();

//            for(int i=0;i<new_arrayListVideoDetails.size();i++){
//                Log.e("VideoDetailsAL",new_arrayListVideoDetails.get(i).getVideoId());
//            }

            for(int x = 0;x<sixth_Details.getChapter().size();x++){
                you_Chapter = (ArrayList<String>) sixth_Details.getChapter().clone();
            }

            Log.e("subject_name",subject_name);

//            for(int x = 0;x<sixth_Details.getVideoTitle().size();x++){
//                videoName = (ArrayList<String>) sixth_Details.getVideoTitle().clone();
//            }
            // youtube_subjectNameModelArrayList.add(sixth_Details);
            //videoDetailsArrayList.add(sixth_Details);
            // number_chapters.setText(jsonArray.length()+" Chapters");
            number_chapters.setText(sixth_Details.getChapter().size()+" Chapters");

            //subjectChapterListAdapter = new SubjectChapterListAdapter(this, you_Chapter, new_arrayListVideoDetails);
            subjectChapterListAdapter = new SubjectChapterListAdapter(this, you_Chapter, playListArrayList);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
            chapter_list_Recyclerview.setLayoutManager(linearLayoutManager);
            chapter_list_Recyclerview.setAdapter(subjectChapterListAdapter);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 201 && resultCode == RESULT_OK) {
            try {
                YouTubeTitle rm = (YouTubeTitle) data.getSerializableExtra("DataFromLand");
                Log.e("Test Data", String.valueOf(rm.getChapter()));
//                landDetailModel = (LandDetailModel) data.getSerializableExtra("LandDetail");
//                Log.e("Land Data", landDetailModel.getArea());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    private void checkOrientation() {
        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    private void listner() {
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                //  startActivity(new Intent(SubjectsSixthClassActivity.this, DashBoardSixthStandardActivity.class));
            }
        });
        pratices_Chapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(SubjectsSixthClassActivity.this, RedThemePracticeActivity.class);
                Intent intent = new Intent(SubjectsSixthClassActivity.this, RedThemeChapterListPracticeActivity.class);
                intent.putExtra("PracticeChap",sixth_Details);
                intent.putExtra("PracticePlayList",playListArrayList);
                startActivity(intent);
            }
        });
        test_subjcet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(SubjectsSixthClassActivity.this, RedThemeTestActivity.class);
                Intent intent = new Intent(SubjectsSixthClassActivity.this, RedThemeChapterListTestActivity.class);
                intent.putExtra("TestChap",sixth_Details);
                intent.putExtra("TestPlayList",playListArrayList);
                startActivity(intent);
            }
        });
    }

    private void getChapterApiCalling() {
        {
            if (!CommonUtilities.isOnline(this)) {
                Toast.makeText(SubjectsSixthClassActivity.this, "Please On Your Internet Connection", Toast.LENGTH_LONG).show();
                return;
            }
            Log.e("course_id", course_id);
            String url = Global.WEBBASE_URL + "getTopicByCourseId?CourseId=" + course_id;
            final String string_json = "Result";
//        JSONObject params = new JSONObject();
//        String mRequestBody = "";

//        mRequestBody = params.toString();
//        Log.e("Request Body", mRequestBody);
//        final String finalMRequestBody = mRequestBody;
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    String res = response.toString();
                    parseResponseChapterApi(res, progressdialog);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //progressDialog.dismiss();
                    NetworkResponse response = error.networkResponse;

                    Log.e("com.Aarambh", "error response " + response);

                    if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                        Log.e("mls", "VolleyError TimeoutError error or NoConnectionError");
                    } else if (error instanceof AuthFailureError) {                    //TODO
                        Log.e("mls", "VolleyError AuthFailureError");
                    } else if (error instanceof ServerError) {
                        Log.e("mls", "VolleyError ServerError");
                    } else if (error instanceof NetworkError) {
                        Log.e("mls", "VolleyError NetworkError");
                    } else if (error instanceof ParseError || error instanceof VolleyError) {
                        Log.e("mls", "VolleyError TParseError");
                        Log.e("Volley Error", error.toString());
                    }
                    if (error instanceof ServerError && response != null) {
                        try {
                            String res = new String(response.data, HttpHeaderParser.parseCharset(response.headers, "utf-8"));
                            // Now you can use any deserializer to make sense of data
                            // progressDialog.show();
                            parseResponseChapterApi(response.toString(), progressdialog);

                        } catch (UnsupportedEncodingException e1) {
                            // Couldn't properly decode data to string
                            e1.printStackTrace();
                        }
                    }

                }
            }) {
                @Override
                public Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<String, String>();
                    params.put("CourseId", course_id);
                    return params;
                }

                @Override
                protected VolleyError parseNetworkError(VolleyError volleyError) {
                    String json;
                    if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                        try {
                            json = new String(volleyError.networkResponse.data,
                                    HttpHeaderParser.parseCharset(volleyError.networkResponse.headers));
                        } catch (UnsupportedEncodingException e) {
                            return new VolleyError(e.getMessage());
                        }
                        return new VolleyError(json);
                    }
                    return volleyError;
                }


                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Authorization", "Bearer " + AarambhSharedPreference.loadUserTokenFromPreference(SubjectsSixthClassActivity.this));
                    return headers;
                }
            };
            VolleySingleton.getInstance(SubjectsSixthClassActivity.this).addToRequestQueue(stringRequest, string_json);

        }
    }

    private void parseResponseChapterApi(String response, ProgressDialog progressdialog) {
        Log.e("chapter_res", response);
        try {
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                Log.e("chapter_length", String.valueOf(i));
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String TopicId = jsonObject.getString("TopicId");
                String TopicName = jsonObject.getString("TopicName");
                Log.e("TopicName", TopicName);
                String TopicOtherDetail = jsonObject.getString("TopicOtherDetail");
                String ClassId = jsonObject.getString("ClassId");
                String CourseId = jsonObject.getString("CourseId");
                String StatusId = jsonObject.getString("StatusId");
                String CreatedById = jsonObject.getString("CreatedById");
                String ModifiedById = jsonObject.getString("ModifiedById");
                String CreationDate = jsonObject.getString("CreationDate");
                String ModificationDate = jsonObject.getString("ModificationDate");
                Log.e("sf-----", String.valueOf(subjectChapterListModelArrayList));
                subjectChapterListModel = new SubjectChapterListModel(TopicId, TopicName, TopicOtherDetail, ClassId, CourseId, StatusId, CreatedById, ModifiedById, CreationDate, ModificationDate);
                subjectChapterListModelArrayList.add(subjectChapterListModel);
            }
//            number_chapters.setText(jsonArray.length()+" Chapters");
//            subjectChapterListAdapter = new SubjectChapterListAdapter(this, subjectChapterListModelArrayList);
//            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
//            chapter_list_Recyclerview.setLayoutManager(linearLayoutManager);
//            chapter_list_Recyclerview.setAdapter(subjectChapterListAdapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onBackPressed() {
        finish();
    }
    @Override
    public void finish() {
        Intent in = new Intent(SubjectsSixthClassActivity.this, DashBoardSixthStandardActivity.class);
        in.putExtra("DataDashBoard6th", you_Chapter);
        //  in.putExtra("LandDetail", landDetailModel);
        in.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        setResult(RESULT_OK, in);
        super.finish();
    }

    public static Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            // Log exception
            return null;
        }
    }
    private void init() {

        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        //themeDynamicAdd();
        Global.total_question_number=0;
        videoDetailsArrayList=new ArrayList<>();

        try {
            profile_subject_tab=(ImageView) findViewById(R.id.img_profile_tab);
            student_name=(TextView) findViewById(R.id.student_name_red);
            student_name.setText(AarambhSharedPreference.loadStudentNameFromPreference(this));
            Glide.with(this).load(urlProfileImg)
                    .crossFade()
                    .thumbnail(0.5f)
                    .bitmapTransform(new CircleTransform(this))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(profile_subject_tab);

        }catch (Exception e){
            e.printStackTrace();
        }

        number_chapters=(TextView)findViewById(R.id.chapter_numbers_red);
        progressdialog = new ProgressDialog(getApplicationContext());
        progressdialog.setMessage("Please Wait....");
        progressdialog.setCancelable(false);
        test_subjcet = findViewById(R.id.test_red_cardview);
        pratices_Chapter = findViewById(R.id.practices_red_cardview);
        subj_name = findViewById(R.id.subj_one_name);
        subj_name.setText(subject_name);
        back_btn = findViewById(R.id.back_btn);
        chapter_list_Recyclerview = findViewById(R.id.chapter_list_recyclerview_sixth_std);
        subjectChapterListModelArrayList = new ArrayList<>();
        practice = (TextView) findViewById(R.id.pratice);
        test = (TextView) findViewById(R.id.test);
        TextColorGradient textColorGradient = new TextColorGradient();
        textColorGradient.getColorTextGradient(practice,"#E13337","#BB3437");
        textColorGradient.getColorTextGradient(test,"#E13337","#BB3437");
    }

    private void themeDynamicAdd() {
        String base_image=AarambhThemeSharedPrefreence.loadBaseImageFromPreference(this);
        String transparent_color=AarambhThemeSharedPrefreence.loadBaseImageTransparentFromPreference(this);
        String base_color_one=AarambhThemeSharedPrefreence.loadBaseColorOneFromPreference(this);
        String base_color_two=AarambhThemeSharedPrefreence.loadBaseColorTwoFromPreference(this);
        //Bitmap myImage = getBitmapFromURL(image);
        try {
            background_theme=findViewById(R.id.background_theme);


            myImage=getBitmapFromURL(base_image);
            Drawable dr = new BitmapDrawable((myImage));
            background_theme.setBackgroundDrawable(dr);


        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
