package com.example.aarambhappdynamictheme.activity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.aarambhappdynamictheme.R;

public class TermsCondiationActivity extends AppCompatActivity {
    ImageView back_btn,tab_profile_icon;
    TextView terms_condition_name,tab_profile_name;
    ArrayList<String> you_Chapter;
    WebView simpleWebView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_condiation);
        checkOrientation();
        init();
        listner();
    }
    private void checkOrientation() {
        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }
    private void listner() {
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        finish();
    }
    @Override
    public void finish() {
        Intent in=new Intent(RedThemeTermsConditionActivity.this, DashBoardSixthStandardActivity.class);
        in.putExtra("DataDashBoard6th", you_Chapter);
        //  in.putExtra("LandDetail", landDetailModel);
        in.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        setResult(RESULT_OK, in);
        super.finish();
    }


    private void init() {
        back_btn = (ImageView) findViewById(R.id.back_btn_terms);
        terms_condition_name = (TextView) findViewById(R.id.terms_condition_name);
        TextColorGradient textColorGradient = new TextColorGradient();
        textColorGradient.getColorTextGradient(terms_condition_name, "#E13337", "#BB3437");
        try {
            tab_profile_icon = (ImageView) findViewById(R.id.img_profile_tab);
            tab_profile_name = (TextView) findViewById(R.id.student_name_red);
            tab_profile_name.setText(AarambhSharedPreference.loadStudentNameFromPreference(this));
            Glide.with(this).load(urlProfileImg)
                    .crossFade()
                    .thumbnail(0.5f)
                    .bitmapTransform(new CircleTransform(this))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(tab_profile_icon);

        } catch (Exception e) {
            e.printStackTrace();
        }
        simpleWebView = (WebView) findViewById(R.id.simpleWebView);
        simpleWebView.setWebViewClient(new MyWebViewClient());
        String url = "https://aarambhapp.com/termsofservicesapp.html";
        simpleWebView.getSettings().setJavaScriptEnabled(true);
        simpleWebView.loadUrl(url); // load the url on the web view
    }
    // custom web view client class who extends WebViewClient
    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url); // load the url
            return true;
        }
//        WebView wv = findViewById(R.id.webView);
//        wv.loadUrl("https://aarambhapp.com/termsofservicesapp.html");
//
//
//        wv.setWebViewClient(new WebViewClient() {
//            @Override
//            public void onPageFinished(WebView view, String url) {
//                view.loadUrl(url);
//            }
//
//            @Override
//            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
//            }
//
//            @Override
//            public void onReceivedHttpError(
//                    WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
//            }
//
//            @Override
//            public void onReceivedSslError(WebView view, SslErrorHandler handler,
//                                           SslError error) {
//            }
//
//
//            @Override
//            public boolean shouldOverrideUrlLoading(WebView view, String url) {
//                view.loadUrl(url);
//                return true;
//            }
//        });
//        wv.loadUrl("https://aarambhapp.com/termsofservicesapp.html");
    }
}
