package com.example.aarambhappdynamictheme.activity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.aarambhappdynamictheme.R;
import com.example.aarambhappdynamictheme.sheardPrefrence.AarambhSharedPreference;
import com.example.aarambhappdynamictheme.textGradient.CircleTransform;
import com.example.aarambhappdynamictheme.util.CommonUtilities;
import com.example.aarambhappdynamictheme.util.Global;
import com.example.aarambhappdynamictheme.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ParentContectUsActivity extends AppCompatActivity {
    ImageView back_btn,tab_profile_icon,tab_notification_bell;
    TextView tab_profile_name;
    TextView grud_name,grud_mobile,graud_address;
    Button save;
    ArrayList<String> you_Chapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_contect_us);
        checkOrientation();
        init();
        listner();
        getDetailParent();
    }

    private void getDetailParent() {
        if (!CommonUtilities.isOnline(this)) {
            Toast.makeText(ParentContectUsActivity.this, "Please On Your Internet Connection", Toast.LENGTH_LONG).show();
            return;
        }
        String url = Global.WEBBASE_URL + "getStudentMainById?studentId="+ AarambhSharedPreference.loadStudentIdFromPreference(this);
        final String string_json = "Result";
        StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                String res = response.toString();
                parseResponseProfileApi(res);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //progressDialog.dismiss();
                NetworkResponse response = error.networkResponse;

                Log.e("com.Aarambh", "error response " + response);

                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                    Log.e("mls", "VolleyError TimeoutError error or NoConnectionError");
                } else if (error instanceof AuthFailureError) {                    //TODO
                    Log.e("mls", "VolleyError AuthFailureError");
                } else if (error instanceof ServerError) {
                    Log.e("mls", "VolleyError ServerError");
                } else if (error instanceof NetworkError) {
                    Log.e("mls", "VolleyError NetworkError");
                } else if (error instanceof ParseError || error instanceof VolleyError) {
                    Log.e("mls", "VolleyError TParseError");
                    Log.e("Volley Error", error.toString());
                }
                if (error instanceof ServerError && response != null) {
                    try {
                        String res = new String(response.data, HttpHeaderParser.parseCharset(response.headers, "utf-8"));
                        // Now you can use any deserializer to make sense of data
                        // progressDialog.show();
                        parseResponseProfileApi(response.toString());

                    } catch (UnsupportedEncodingException e1) {
                        // Couldn't properly decode data to string
                        e1.printStackTrace();
                    }
                }

            }
        }){
            @Override
            public Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<String, String>();
                params.put("studentId", AarambhSharedPreference.loadStudentIdFromPreference(ParentContectUsActivity.this));
                return params;
            }

            @Override
            protected VolleyError parseNetworkError(VolleyError volleyError) {
                String json;
                if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                    try {
                        json = new String(volleyError.networkResponse.data,
                                HttpHeaderParser.parseCharset(volleyError.networkResponse.headers));
                    } catch (UnsupportedEncodingException e) {
                        return new VolleyError(e.getMessage());
                    }
                    return new VolleyError(json);
                }
                return volleyError;
            }


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                headers.put("Authorization", "Bearer "+ AarambhSharedPreference.loadUserTokenFromPreference(ParentContectUsActivity.this));
                return headers;
            }
        };
        VolleySingleton.getInstance(ParentContectUsActivity.this).addToRequestQueue(stringRequest, string_json);

    }
    private void parseResponseProfileApi(String response) {
        Log.e("class_res",response);
        try {
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                Log.e("class_lenth", String.valueOf(i));
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String StudentId = jsonObject.getString("StudentId");
                Log.e("StudentId",StudentId);
                String StudentAltMob = jsonObject.getString("StudentAltMob");
                grud_mobile.setText(StudentAltMob);
                String StudentGuardianName = jsonObject.getString("StudentGuardianName");
                grud_name.setText(StudentGuardianName);
                String ClassId = jsonObject.getString("ClassId");
                String StatusId = jsonObject.getString("StatusId");
                String CreatedById = jsonObject.getString("CreatedById");
                String ModifiedById = jsonObject.getString("ModifiedById");
                String CreationDate = jsonObject.getString("CreationDate");
                String ModificationDate = jsonObject.getString("ModificationDate");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void init() {
        you_Chapter=new ArrayList<>();
        back_btn=(ImageView)findViewById(R.id.back_btn_parent);
        grud_name=(TextView) findViewById(R.id.parent_name_edit);
        grud_mobile=(TextView) findViewById(R.id.parent_mobile_number);
        graud_address=(TextView)findViewById(R.id.parent_adddress_Profile);
        //save=(Button)findViewById(R.id.save_detail);
        try {
            tab_profile_icon=(ImageView) findViewById(R.id.img_profile_tab);
            tab_profile_name=(TextView) findViewById(R.id.student_name_red);
            tab_profile_name.setText(AarambhSharedPreference.loadStudentNameFromPreference(this));
            Glide.with(this).load(urlProfileImg)
                    .crossFade()
                    .thumbnail(0.5f)
                    .bitmapTransform(new CircleTransform(this))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(tab_profile_icon);

        }catch (Exception e){
            e.printStackTrace();
        }


    }

    private void listner() {
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
//        save.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String parent_name=grud_name.getText().toString().trim();
//                String parent_number=grud_mobile.getText().toString().trim();
//                if (parent_name.isEmpty()){
//                    grud_name.setError("Please Enter Parent Name.");
//                    grud_name.requestFocus();
//                }else if (parent_number.isEmpty()){
//                    grud_mobile.setError("Please Enter Parent Mobile Number.");
//                    grud_mobile.requestFocus();
//                }else{
//                    parentDataUpdate();
//                }
//            }
//        });

    }
    //    private void parentDataUpdate() {
//        if (!CommonUtilities.isOnline(this)) {
//            Toast.makeText(RedThemeParentContectActivity.this, "Please On Your Internet Connection", Toast.LENGTH_LONG).show();
//            return;
//        }
//        String url = Global.WEBBASE_URL + "updateStudent";
//        VolleyMultipartRequest multipartRequest=new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
//            @Override
//            public void onResponse(NetworkResponse response) {
//                String resultResponse = new String(response.data);
//                parseResponseUpdateProfile(resultResponse);
//                Log.e("Response",resultResponse);
//                //  parseResponseUpdateProfile(String.valueOf(response));
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                NetworkResponse networkResponse = error.networkResponse;
//                String errorMessage = "Unknown error";
//                if (networkResponse == null) {
//                    if (error.getClass().equals(TimeoutError.class)) {
//                        errorMessage = "Request timeout";
//                    } else if (error.getClass().equals(NoConnectionError.class)) {
//                        errorMessage = "Failed to connect server";
//                    }
//                } else {
//                    try {
//                        String result = new String(networkResponse.data);
//                        Log.e("Result",result);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                }
//                Log.i("Error", errorMessage);
//                error.printStackTrace();
//            }
//        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//                params.put("StudentId", AarambhSharedPreference.loadStudentIdFromPreference(RedThemeParentContectActivity.this));
//                Log.e("student_id",AarambhSharedPreference.loadStudentIdFromPreference(RedThemeParentContectActivity.this));
//                params.put("StudentGuardianName", grud_name.getText().toString().trim());
//                params.put("StudentAltMob", grud_mobile.getText().toString().trim());
//                params.put("ClassId", AarambhSharedPreference.loadClassIdFromPreference(RedThemeParentContectActivity.this));
//                Log.e("ClassId", AarambhSharedPreference.loadClassIdFromPreference(RedThemeParentContectActivity.this));
//                params.put("StatusId", "1");
//                params.put("CreatedById", "1");
//                params.put("CreationDate", "");
//                params.put("ModifiedById", "1");
//                params.put("ModificationDate", "2020-02-26");
//                Log.e("apiData---", (params).toString());
//                return params;
//            }
//            @Override
//            protected Map<String, DataPart> getByteData() {
//                Map<String, DataPart> params = new HashMap<>();
//                // file name could found file base or direct access from real path
//                // for now just get bitmap data from ImageView
////                profile_uri=new DataPart("img", AppHelper.getBitmap(RedTheme_UpdateProfile.this, profilebitmap), "image/jpeg");
////                params.put("StudentImage", profile_uri);
////                Log.e("profileData", String.valueOf(profile_uri));
//                return params;
//            }
//
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                HashMap<String, String> headers = new HashMap<String, String>();
//                //headers.put("Content-Type", "application/json; charset=utf-8");
//                headers.put("Authorization", "Bearer " + AarambhSharedPreference.loadUserTokenFromPreference(RedThemeParentContectActivity.this));
//                return headers;
//            }
//        };
//        multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
//                Global.WEBSERVICE_TIMEOUT_VALUE_IN_MILLIS,
//                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
//                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
//        ));
//        multipartRequest.setShouldCache(false);
//        VolleySingletonImage.getInstance(RedThemeParentContectActivity.this).addToRequestQueue(multipartRequest);
//    }
//    private void parseResponseUpdateProfile(String response) {
//        try {
//            JSONObject obj = new JSONObject(response);
//            //boolean result = obj.getBoolean("Result");
//            String message = obj.getString("Message");
//            Log.e("response", response);
//            Log.e("massage", message);
//            // Log.e("Insert Response: ", result + "");
//            if (message.equalsIgnoreCase("Student Updated Successfully.")) {
//                Toast.makeText(RedThemeParentContectActivity.this,"Saved Successfully.",Toast.LENGTH_LONG).show();
//                Intent intent=new Intent(RedThemeParentContectActivity.this, DashBoardSixthStandardActivity.class);
//                startActivity(intent);
//            }
//            else {
//                Toast.makeText(this, "Updatedation Failed.Pls Try Again", Toast.LENGTH_LONG).show();
//                //progressDialog.dismiss();
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }
//
    private void checkOrientation() {
        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }
    @Override
    public void onBackPressed() {
        finish();
//        Intent intent=new Intent(RedThemeParentContectActivity.this, DashBoardSixthStandardActivity.class);
//    startActivity(intent);
    }

    @Override
    public void finish() {
        Intent intent=new Intent(ParentContectUsActivity.this, DashBoardActivity.class);
        intent.putExtra("DataDashBoard6th", you_Chapter);
        //  in.putExtra("LandDetail", landDetailModel);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        setResult(RESULT_OK, intent);
        super.finish();
    }
}
