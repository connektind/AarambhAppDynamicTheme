package com.example.aarambhappdynamictheme.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.aarambhappdynamictheme.R;

import java.util.ArrayList;

public class PaticesChapterListActivity extends AppCompatActivity {
    RecyclerView chapter_list_recyclerview_sixth_std_test;
    ArrayList<PracticeData> testDataArrayList;
    PracticeChapterListAdapter practiceChapterListAdapter;

    ArrayList<YouTubePlayList> playListArrayList;
    ArrayList<String> you_Chapter;
    YouTubeTitle sixth_Details;
    ImageView back_btn;
    TextView chapter_number,chapter_name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patices_chapter_list);
        init();
        listener();
    }

    public void init() {
        chapter_number=findViewById(R.id.chapter_numbers_red);
        chapter_name=findViewById(R.id.subj_one_name);
        try {
            back_btn = findViewById(R.id.back_btn);
            sixth_Details = (YouTubeTitle) getIntent().getSerializableExtra("PracticeChap");
            playListArrayList = (ArrayList<YouTubePlayList>) getIntent().getSerializableExtra("PracticePlayList");
            you_Chapter = new ArrayList<>();
            Log.e("SixthDetails Size",sixth_Details.getChapter().size()+"");
            for (int x = 0; x < sixth_Details.getChapter().size(); x++) {
                you_Chapter = (ArrayList<String>) sixth_Details.getChapter().clone();
            }
            Log.e("You Chapter Test",you_Chapter.size()+""); //2
            chapter_number.setText(you_Chapter.size()+" Chapters");
            chapter_name.setText(AarambhSharedPreference.loadSubjectNameFromPreference(this));
            chapter_list_recyclerview_sixth_std_test = findViewById(R.id.chapter_list_recyclerview_sixth_std_test);
            practiceChapterListAdapter = new PracticeChapterListAdapter(RedThemeChapterListPracticeActivity.this,you_Chapter,playListArrayList );
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
            chapter_list_recyclerview_sixth_std_test.setLayoutManager(linearLayoutManager);
            chapter_list_recyclerview_sixth_std_test.setAdapter(practiceChapterListAdapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void listener() {
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
