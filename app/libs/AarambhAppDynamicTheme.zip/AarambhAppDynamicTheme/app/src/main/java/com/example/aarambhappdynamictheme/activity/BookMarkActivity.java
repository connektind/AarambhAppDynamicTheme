package com.example.aarambhappdynamictheme.activity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.aarambhappdynamictheme.R;
import com.example.aarambhappdynamictheme.adapter.BookMarkPageAdapter;
import com.example.aarambhappdynamictheme.sheardPrefrence.AarambhSharedPreference;
import com.example.aarambhappdynamictheme.textGradient.CircleTransform;
import com.example.aarambhappdynamictheme.textGradient.TextColorGradient;

import java.util.ArrayList;

import static com.example.aarambhappdynamictheme.util.Global.urlProfileImg;

public class BookMarkActivity extends AppCompatActivity {
    TabLayout tab;
    ViewPager viewPager;
    Button back_btn;
    TextView bookmark_red_name;
    ImageView profile_subject_tab;
    TextView student_name;
    ArrayList<String> subject_list;
    ArrayList<String> you_Chapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_mark);
        checkOrientation();
        try {
            subject_list=getIntent().getStringArrayListExtra("SubjectList");
            Log.e("datalistBookmark", String.valueOf(subject_list.size()));
        }catch (Exception e){
            e.printStackTrace();
        }
        init();
        listner();
    }
    private void checkOrientation() {
        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }


    private void listner() {
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_btn.setEnabled(false);
                finish();
//                Intent intent=new Intent(RedThemeBookMarkActivity.this, DashBoardSixthStandardActivity.class);
//                startActivity(intent);
//                finishAffinity();
            }
        });
        for (int k = 0; k <subject_list.size(); k++) {
            tab.addTab(tab.newTab().setText(subject_list.get(k)));

//            switch (k){
//                case 0:
//                    tab.addTab(tab.newTab().setText("All"));
//                    break;
//                case 1:
//                    tab.addTab(tab.newTab().setText("Hindi"));
//                    break;
//                case 2:
//                    tab.addTab(tab.newTab().setText("English"));
//                    break;
//                case 3:
//                    tab.addTab(tab.newTab().setText("Maths"));
//                    break;
//                case 4:
//                    tab.addTab(tab.newTab().setText("Science"));
//                    break;
//                case 5:
//                    tab.addTab(tab.newTab().setText("Gk"));
//                    break;
//            }
        }
        BookMarkPageAdapter adapter = new BookMarkPageAdapter
                (getSupportFragmentManager(), tab.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(1);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tab));
//Bonus Code : If your tab layout has more than 2 tabs then tab will scroll other wise they will take whole width of the screen
        if (tab.getTabCount() == 2) {
            tab.setTabMode(TabLayout.MODE_FIXED);
        } else {
            tab.setTabMode(TabLayout.MODE_SCROLLABLE);
        }

    }

    private void init() {
        you_Chapter=new ArrayList<>();
        try {
            profile_subject_tab=(ImageView) findViewById(R.id.img_profile_tab);
            student_name=(TextView) findViewById(R.id.student_name_red);
            student_name.setText(AarambhSharedPreference.loadStudentNameFromPreference(this));
            Glide.with(this).load(urlProfileImg)
                    .crossFade()
                    .thumbnail(0.5f)
                    .bitmapTransform(new CircleTransform(this))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(profile_subject_tab);

        }catch (Exception e){
            e.printStackTrace();
        }
        bookmark_red_name=findViewById(R.id.bookmark_red_name);
        TextColorGradient textColorGradient=new TextColorGradient();
        textColorGradient.getColorTextGradient(bookmark_red_name,"#E13337","#BB3437");
        back_btn=findViewById(R.id.back_btn_bookmark);
        tab=findViewById(R.id.tabs);
        viewPager=findViewById(R.id.frameLayout);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
    @Override
    public void finish() {
        try {
            Intent in = new Intent(BookMarkActivity.this, DashBoardActivity.class);
            in.putExtra("DataDashBoard6th", you_Chapter);
            //  in.putExtra("LandDetail", landDetailModel);
            in.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            setResult(RESULT_OK, in);
            super.finish();
        }catch (Exception e){
            Toast.makeText(this,"Please On Your Internet Connection",Toast.LENGTH_LONG).show();
            Intent in = new Intent(BookMarkActivity.this, DashBoardActivity.class);
            startActivity(in);
        }
    }

}
