package com.example.aarambhappdynamictheme.sheardPrefrence;

import android.content.Context;
import android.content.SharedPreferences;

public class AarambhThemeSharedPrefreence {
    public static final String PREFS_NAME = "AARAMBH_THEME";
    public static final String GUEST = "Guest";
    public static final String BASE_IMAGE="BaseImage";
    public static final String BASE_IMAGE_TRANSPARENT="BaseImageTransparent";
    public static final String BASE_COLOR_ONE="BaseColorOne";
    public static final String BASE_COLOR_TWO="BaseColorTwo";

    public static void saveBaseImageToPreference(Context context, String BaseImage){
        try{
            SharedPreferences.Editor editor =  context.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE).edit();
            editor.putString(BASE_IMAGE,BaseImage);
            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String loadBaseImageFromPreference(Context ctx){
        String BaseImage="";
        try{
            SharedPreferences pref = ctx.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE);
            BaseImage = pref.getString(BASE_IMAGE,"NA");
        }catch (Exception e){
            e.printStackTrace();
        }
        return BaseImage;
    }

    public static void saveBaseImageTransparentToPreference(Context context, String BaseImageTransparent){
        try{
            SharedPreferences.Editor editor =  context.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE).edit();
            editor.putString(BASE_IMAGE_TRANSPARENT,BaseImageTransparent);
            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String loadBaseImageTransparentFromPreference(Context ctx){
        String BaseImageTransparent="";
        try{
            SharedPreferences pref = ctx.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE);
            BaseImageTransparent = pref.getString(BASE_IMAGE_TRANSPARENT,"NA");
        }catch (Exception e){
            e.printStackTrace();
        }
        return BaseImageTransparent;
    }
    public static void saveBaseColorOnePreference(Context context, String BaseColorOne){
        try{
            SharedPreferences.Editor editor =  context.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE).edit();
            editor.putString(BASE_COLOR_ONE,BaseColorOne);
            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String loadBaseColorOneFromPreference(Context ctx){
        String BaseColorOne="";
        try{
            SharedPreferences pref = ctx.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE);
            BaseColorOne = pref.getString(BASE_COLOR_ONE,"NA");
        }catch (Exception e){
            e.printStackTrace();
        }
        return BaseColorOne;
    }
    public static void saveBaseColorTwoPreference(Context context, String BaseColorTwo){
        try{
            SharedPreferences.Editor editor =  context.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE).edit();
            editor.putString(BASE_COLOR_TWO,BaseColorTwo);
            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String loadBaseColorTwoFromPreference(Context ctx){
        String BaseColorTwo="";
        try{
            SharedPreferences pref = ctx.getSharedPreferences(PREFS_NAME,Context.MODE_PRIVATE);
            BaseColorTwo = pref.getString(BASE_COLOR_TWO,"NA");
        }catch (Exception e){
            e.printStackTrace();
        }
        return BaseColorTwo;
    }
}
