package com.example.aarambhappdynamictheme.util;

public class Global {

    public static final String WEBBASE_URL = "http://35.200.220.64:1231/aarambh/";
    public static final int WEBSERVICE_TIMEOUT_VALUE_IN_MILLIS = 60000; // 1min
    public static final String YOUTUBE_API_KEY = "AIzaSyAja-68gRGjnbSCsR5U1IuMKpUUO8rABmo";

  //  public static final  String profilr_img=AarambhSharedPreference.loadStudentProfileFromPreference(context);
    public static final String urlProfileImg = "https://i.pinimg.com/736x/1a/db/d0/1adbd0781d532668d66d7e12753d16e4.jpg";
public static final String urlStudentImg = "http://35.200.220.64:1231/profile/";

//public static int correct_answer_test=0;
//    public static int wrong_answer_test=0;
    public static int total_question_number=0;



}
