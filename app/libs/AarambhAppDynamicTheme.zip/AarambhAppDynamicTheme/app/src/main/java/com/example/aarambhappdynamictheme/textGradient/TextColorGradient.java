package com.example.aarambhappdynamictheme.textGradient;

import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.text.TextPaint;
import android.widget.TextView;

public class TextColorGradient {

    public void getColorTextGradient(TextView text,String start_color,String end_color) {
        TextPaint paint = text.getPaint();
        float width = paint.measureText("");

        Shader textShader = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {

            textShader = new LinearGradient(0, 0, width, text.getTextSize(),
                    new int[]{
                             Color.parseColor(start_color),
                             Color.parseColor(end_color),
                    }, null, Shader.TileMode.CLAMP);

        }
        text.getPaint().setShader(textShader);
    }
}
