package com.example.aarambhappdynamictheme.activity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.aarambhappdynamictheme.R;
import com.example.aarambhappdynamictheme.sheardPrefrence.AarambhSharedPreference;
import com.example.aarambhappdynamictheme.textGradient.CircleTransform;
import com.example.aarambhappdynamictheme.textGradient.TextColorGradient;

import java.util.ArrayList;

import static com.example.aarambhappdynamictheme.util.Global.urlProfileImg;

public class NotificationActivity extends AppCompatActivity {
    ImageView back_btn_notification;
    TextView notification_name;
    ImageView notification_icon;
    TextView bookmark_red_name;
    ImageView profile_subject_tab;
    TextView student_name;
    ArrayList<String> you_Chapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        checkOrientation();
        init();
        listner();
    }
    private void checkOrientation() {
        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    private void listner() {
        back_btn_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }
    @Override
    public void finish() {
        Intent in = new Intent(NotificationActivity.this, DashBoardActivity.class);
        in.putExtra("DataDashBoard6th", you_Chapter);
        //  in.putExtra("LandDetail", landDetailModel);
        in.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        setResult(RESULT_OK, in);
        super.finish();
    }


    private void init() {
        you_Chapter=new ArrayList<>();
        try {
            profile_subject_tab=(ImageView) findViewById(R.id.img_profile_tab);
            student_name=(TextView) findViewById(R.id.student_name_red);
            student_name.setText(AarambhSharedPreference.loadStudentNameFromPreference(this));
            Glide.with(this).load(urlProfileImg)
                    .crossFade()
                    .thumbnail(0.5f)
                    .bitmapTransform(new CircleTransform(this))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(profile_subject_tab);

        }catch (Exception e){
            e.printStackTrace();
        }
        notification_icon=(ImageView)findViewById(R.id.notfication_icon_red);
        notification_name=(TextView) findViewById(R.id.notfication_name);
        back_btn_notification = (ImageView) findViewById(R.id.back_btn_notification);
        TextColorGradient textColorGradient=new TextColorGradient();
        textColorGradient.getColorTextGradient(notification_name,"#E13337","#BB3437");
    }
}
